# Field Notes Calendar API

This project provides a calendar API for defence expos, NATO trials, and export-control deadlines.

## Usage

Deploy to Vercel, then query:

